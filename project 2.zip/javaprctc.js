
const form = document.querySelector('form')
const ul = document.querySelector('ul')
const button = document.querySelector('button')
const input = document.getElementById('prj')

Let prjArray = localStorage.getItem('prj') ? JSON.parse(localStorage.getItem('prj')): []

localStorage.setItem('prj', JSON.stringify(prjArray))
const data = JSON.parse(localStorage.getItem('prj'))

const list = text => {
    const li = document.createElement('li')
    li.textContent = text
    ul.appendChild(li)
}

form.addEventListener('submit', function(e){
    e.preventDefault()

    prjArray.push(input.value)
    localStorage.setItem('prj', JSON.stringify(prjArray))
    list(input.value)
    input.value = ''
});

data.forEach(Prj => {
    list(prjArray)
});
window.onload = function(){
    var lis = document.getElementById('projects').getElementsByTagName('li');
    for (i=0; i<lis.length;i++){
        lis[i].onclick = link();
    }
}
function link(){

}
function store(){
    var inputList = document.getElementById("btn");
    localStorage.setItem("btn", inputList.value)
}

/*button.addEventListener('click', function(){
    localStorage.clear()
    while(ul.firstChild){
        ul.removeChild(ul.firstChild)
    }
})*/


/*
(function(){
    var previousOnload = window.onload;
    var fullyLoaded = functon(){
        var ul = document.getElementById('projects');
        var lis = ul.getElementsByTagName('li'), i =lis.length;
        while(i--){
            if (!(li = lis[i])){continue};
            if(li.attachEvent){
                li.attachEvent('click', clickEvent);
            }
            else if(li.addEventListener){
                li.addEventListener('click', clickEvent);
            }
        }
    }
    var clickEvent = function(){
        switch(i){
            case 0: 
        }
    }
    window.onload = function(){
        fullyLoaded()
        if(previousOnload){
            previousOnload();
        }
    }
})*/
